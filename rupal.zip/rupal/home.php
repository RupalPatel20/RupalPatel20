<?php

  session_start();

  if (!isset($_SESSION['username'])) {
  header(" Location: index.php");
  }

  ?>

  <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>      
   <link rel="stylesheet" href="./assets/css/style33.css" >
</head>
    <body class="sixteen">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark pt-2 pb-2" style="position:sticky; top:0px; z-index:1100; ">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Blogging Website</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/rupal/home.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/rupal/index2.php">Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/rupal/about.html">About us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/rupal/logout.php">Logout</a>
        </li>
      
        
      </div>
  </div>
</nav>
<section>

<div class="d-flex justify-content-center mt-5 p-5">
 <div class="grid">
        <div class="grid-item">
            <div class="card">
                <img class="card-img" src="http://localhost/rupal/assets/image/Lakme..jpg" alt="LAKME" />
                <div class="card-content">
                    <h1 class="card-header">LAKME COSMETICS</h1>
                    <div class="card-body">
                      <a href="http://localhost/rupal/Lakme.html" class="card-btn">Visit</a><span>&rarr;</span></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="grid-item">
            <div class="card">
                <img class="card-img" src="http://localhost/rupal/assets/image/nykaa.jpg" alt="Nykaa" />
                <div class="card-content">
                    <h1 class="card-header">NYKAA COSMETICS</h1>
                    <p class="card-text">

                    </p>
                    <a href="http://localhost/rupal/Nykaa.html" button class="card-btn">Visit</a><span>&rarr;</span></button>
                </div>
            </div>
        </div>
        <div class="grid-item">
            <div class="card">
                <img class="card-img" src="http://localhost/rupal/assets/image/Lotus.jpg" alt="lotus" />
                <div class="card-content">
                    <h1 class="card-header">LOTUS COSMETICS</h1>
                    <p class="card-text">

                    </p>
                <a href="http://localhost/rupal/Lotus.html" button class="card-btn">Visit</a><span>&rarr;</span></button>
                </div>
            </div>
        </div>
        <div class="grid-item">
            <div class="card">
                <img class="card-img" src="http://localhost/rupal/assets/image/Mac.jpg" alt="MAC" />
                <div class="card-content">
                    <h1 class="card-header">MAC COSMETICS</h1>
                    <p class="card-text">

                    </p>
                  <a href="http://localhost/rupal/Mac.html" button class="card-btn">Visit</a><span>&rarr;</span></button>
                </div>
            </div>
        </div>

        <div class="grid-item">
            <div class="card">
                <img class="card-img" src="http://localhost/rupal/assets/image/Avon.webp" alt="AVON" />
                <div class="card-content">
                    <h1 class="card-header">AVON COSMETICS</h1>
                    <p class="card-text">

                    </p>
                   <a href="http://localhost/rupal/Avon.html" button class="card-btn">Visit</a><span>&rarr;</span></button>
                </div>
            </div>
        </div>

    </div> 
    </div>
    

  </body>
</html>
